# MANUAL OFICIAL DE OPERACIONES Y SOPORTE TÉCNICO
**Trip Now — Renta de Vehículos en El Salvador**
*Versión Documental: 3.2.0 | Clasificación: Documento de Soporte Corporativo & Procedimientos TI*
*Publicado: Octubre 2026 | Responsable: Isaac Pérez (Administración & DevOps)*

---

## 1. RESUMEN EJECUTIVO Y PERFIL DE LA EMPRESA

### 1.1 ¿Qué es Trip Now?
**Trip Now** es una plataforma web integral de movilidad y arrendamiento vehicular diseñada exclusivamente para el mercado de El Salvador, Centroamérica. Facilita la reserva inmediata de camionetas 4x4, SUVs familiares, sedanes ejecutivos y compactos económicos, conectando las principales terminales y ciudades turísticas del país.

### 1.2 Misión y Propuesta de Valor
- **Transparencia Total:** Tarifas fijas en Dólares de los Estados Unidos (USD), sin cobros ocultos de última hora.
- **Cobertura Estratégica 24/7:** Entrega directa en el Aeropuerto Internacional San Óscar Arnulfo Romero y Galdámez (SAL), San Salvador (Paseo Escalón), Santa Ana, San Miguel y la zona costera de Surf City (Playa El Tunco).
- **Arquitectura Híbrida de Alta Disponibilidad:** Sincronización en tiempo real con bases de datos en la nube (Firebase Firestore) combinada con un puente serverless directo a Google Sheets para contabilidad y reportería inmediata.

---

## 2. ARQUITECTURA DE LA APLICACIÓN Y SISTEMAS

```
┌─────────────────────────────────────────────────────────────────┐
│                     CLIENTE / NAVEGADOR WEB                    │
│   React 19 + TypeScript + Vite + Tailwind CSS + Lucide Icons   │
│   (Soporte Bilingüe ES/EN · Modo Claro / Modo Oscuro)          │
└────────────────┬───────────────────────────────┬────────────────┘
                 │                               │
                 ▼                               ▼
┌────────────────────────────────┐ ┌──────────────────────────────┐
│       FIREBASE FIRESTORE       │ │      GOOGLE APPS SCRIPT      │
│  · Colección 'reservas'        │ │      (Bridge Webhook)        │
│  · Colección 'clientes'        │ │              │               │
│  · Bitácora 'movimientos'      │ └──────────────┬───────────────┘
│  (Persistencia en Tiempo Real) │                ▼
└────────────────────────────────┘ ┌──────────────────────────────┐
                                   │     GOOGLE SHEETS CLOUD      │
                                   │  · Pestaña: Clientes         │
                                   │  · Pestaña: Viajes/Reservas  │
                                   └──────────────────────────────┘
```

---

## 3. MANUAL DEL CLIENTE Y FLUJO DE RESERVAS

### 3.1 Portal de Bienvenida y Registro Obligatorio (Welcome Gate)
Al ingresar por primera vez a la plataforma, el sistema despliega el **Portal de Bienvenida**.
- **Propósito:** Prevenir reservas anónimas y validar la identidad del conductor.
- **Campos Requeridos:**
  1. *Nombre Completo:* Tal como aparece en su documento de identidad.
  2. *Correo Electrónico:* Clave de sincronización para su historial de viajes.
  3. *Teléfono / WhatsApp:* Para contacto y confirmación del despacho vehicular.
  4. *Documento (DUI, Pasaporte o Licencia):* Validación reglamentaria de tránsito.

### 3.2 Catálogo de Flota y Filtros Avanzados
El cliente puede filtrar y ordenar los vehículos según su necesidad:
- **Categorías:** Camioneta 4x4, SUV, Sedán, Compacto.
- **Transmisión:** Automático o Manual.
- **Combustible:** Gasolina, Híbrido, Eléctrico.
- **Acciones:**
  - *Agregar al Carrito:* Permite seleccionar múltiples días o varios vehículos para grupos.
  - *Alquilar Ahora:* Salto directo a la confirmación de recogida.

### 3.3 Carrito y Agendamiento de Recogida
1. Selección de sucursal de entrega (ej. Aeropuerto SAL con atención continua).
2. Selección de fecha de retiro mediante calendario interactivo.
3. El sistema calcula automáticamente el total en USD y la fecha estimada de devolución.
4. Al confirmar la reserva:
   - Se reduce el stock físico del vehículo en tiempo real.
   - Se crea el registro en Firebase Firestore.
   - Se genera una fila en el libro de cálculo contable de Google Sheets.
   - El cliente recibe un comprobante digital con ID de reserva.

---

## 4. MANUAL OPERATIVO PARA EL ADMINISTRADOR (PANEL DE CONTROL)

### 4.1 Credenciales y Acceso Seguro
El panel administrativo está protegido contra accesos no autorizados mediante autenticación en sesión:
- **Ruta de Acceso:** Botón con ícono de escudo en el menú superior o enlace *"Administración"* en el pie de página.
- **Usuario:** `isaac`
- **Contraseña:** `tocino2023`

### 4.2 Módulos del Panel Administrativo

#### Módulo A: Gestión de Flota e Inventario
- **Añadir Vehículo:** Formulario para subir nuevo modelo, marca, categoría, transmisión, precio por día, stock inicial y URL de imagen.
- **Pausa Operativa (Mantenimiento):** Un vehículo pausado queda oculto del catálogo de los clientes sin perder su historial de reservas.
- **Ajuste de Stock:** Botones rápidos `+` y `-` para controlar las unidades disponibles en patio.
- **Eliminación Segura:** Retira el vehículo si ha sido dado de baja o vendido.

#### Módulo B: Control de Reservas y Estados
Cada reserva pasa por tres estados posibles:
1. **En Curso (Activa):** El cliente tiene el vehículo asignado o pendiente de entrega.
2. **Finalizado (Retorno):** El cliente devolvió el vehículo. Al marcar este estado, el stock del vehículo se reintegra automáticamente al inventario disponible.
3. **Cancelado:** Se anula la reserva y se devuelve el cupo al inventario.
*Ambos cambios se propagan de inmediato a Google Sheets y Firebase.*

#### Módulo C: CRM de Clientes y Auditoría de Datos
- Tabla con conteo acumulado de reservas y total facturado en USD por cliente.
- **Eliminación Individual de Cliente:** Permite borrar un registro específico con confirmación.
- **Eliminar Todos los Clientes (Depuración):** Botón rojo protegido para limpiezas de prueba antes de temporada alta.
- **Bitácora en Vivo:** Monitor de eventos (Live Log) que registra en tiempo real cada reserva, inicio de sesión o actualización de estado.

#### Módulo D: Configuración del Puente Google Sheets
- Permite pegar la URL del Webhook de Google Apps Script.
- Cuenta con un botón **"Probar Conexión"** que verifica la respuesta del servidor en milisegundos.
- Incluye el código fuente oficial listo para copiar e implementar en extensiones de Google Sheets.

---

## 5. GUÍA DE RESOLUCIÓN DE INCIDENCIAS (TROUBLESHOOTING)

| Incidencia Detectada | Causa Posible | Solución Inmediata de Soporte |
| :--- | :--- | :--- |
| **El cliente no puede agregar al carrito** | El vehículo tiene `stock = 0` o está en pausa por taller. | Ingresar al Panel Admin -> Gestión de Flota -> Aumentar stock o despausar el vehículo. |
| **No aparece el registro en Google Sheets** | URL del Webhook desactualizada o permisos en Google Apps Script no configurados en 'Cualquiera (Anyone)'. | En Google Sheets: *Implementar > Nueva Implementación > Acceso: Cualquier usuario*. Copiar la URL web y pegarla en la pestaña *Base de Datos* del Admin. |
| **El mapa de sucursales no carga** | Conexión lenta o bloqueo de scripts de mapas. | El mapa utiliza Leaflet con tiles de OpenStreetMap libres de API key. Verificar conexión a internet del cliente y recargar con `Ctrl + F5`. |
| **El favicon no se visualiza en el navegador** | Caché persistente en navegadores Chromium/Safari. | El archivo `favicon.png` y `favicon.ico` está activo en el servidor. Presionar `Ctrl + Shift + R` o probar en una ventana de incógnito. |

---

## 6. DIRECTORIO DE SUCURSALES Y CANALES DE SOPORTE

- **Central Telefónica El Salvador:** +503 2264-9800
- **Mostrador Aeropuerto Internacional (SAL):** +503 2344-7700 *(Atención 24 Horas)*
- **Línea WhatsApp de Asistencia Vial:** +503 7845-1234
- **Repositorio Oficial en GitHub:** [https://github.com/isaacoswaldoperez551-gif/TripNowFinalAPP](https://github.com/isaacoswaldoperez551-gif/TripNowFinalAPP)
- **Despliegue en Vivo:** [https://isaacoswaldoperez551-gif.github.io/TripNowFinalAPP/](https://isaacoswaldoperez551-gif.github.io/TripNowFinalAPP/)
